﻿# 馃専 Halo Blog

> A lightweight personal blog system built with Python, inspired by [Halo CMS](https://halo.run/).

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Python 3.12+](https://img.shields.io/badge/Python-3.12+-green.svg)](https://www.python.org/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.115+-009688.svg)](https://fastapi.tiangolo.com/)
[![Docker](https://img.shields.io/badge/Docker-Ready-blue.svg)](https://www.docker.com/)

---

## 鉁?Features

- 馃摑 **鏂囩珷绠＄悊** 鈥?Markdown 缂栬緫鍣?+ 瀹炴椂棰勮
- 馃搨 **鍒嗙被绯荤粺** 鈥?鏂囩珷鍒嗙被绠＄悊
- 馃彿锔?**鏍囩绯荤粺** 鈥?鏍囩浜?+ 鏍囩绛涢€?- 馃挰 **璇勮绯荤粺** 鈥?璁垮璇勮 + 绠＄悊鍛樺鏍?+ 宓屽鍥炲
- 馃敆 **鍙嬫儏閾炬帴** 鈥?鍙嬮摼绠＄悊
- 馃搳 **鏁版嵁浠〃鐩?* 鈥?缁熻姒傝
- 馃攼 **JWT 璁よ瘉** 鈥?瀹夊叏鐨勭鐞嗗悗鍙?- 馃摫 **鍝嶅簲寮忚璁?* 鈥?绉诲姩绔弸濂?- 馃惓 **Docker 閮ㄧ讲** 鈥?涓€閿惎鍔?
## 馃殌 Quick Start

### Docker Compose (Recommended)

```bash
# Clone the repository
git clone https://github.com/ArcaneCoreX-dev/halo-blog.git
cd halo-blog

# Start the application
docker compose up -d

# Access the application
# Frontend: http://localhost:8000
# Admin:    http://localhost:8000/admin
# Default:  admin / admin123
```

### Local Development

```bash
# Install dependencies
pip install -e ".[dev]"

# Copy environment file
cp .env.example .env

# Start the server
uvicorn src.main:app --reload --port 8000
```

### Windows One-Click

Double-click `涓€閿惎鍔?bat` to start automatically.

## 馃摳 Screenshots

> Add screenshots here after deployment

```
鈹屸攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹?鈹? 馃彔 棣栭〉                                鈹?鈹? 鈹屸攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹?   鈹?鈹? 鈹? 鏂囩珷鍒楄〃 + 渚ц竟鏍?             鈹?   鈹?鈹? 鈹? 鈹屸攢鈹€鈹€鈹€鈹€鈹€鈹€鈹?鈹屸攢鈹€鈹€鈹€鈹€鈹€鈹€鈹?          鈹?   鈹?鈹? 鈹? 鈹?鏂囩珷1 鈹?鈹?鏂囩珷2 鈹? ...      鈹?   鈹?鈹? 鈹? 鈹斺攢鈹€鈹€鈹€鈹€鈹€鈹€鈹?鈹斺攢鈹€鈹€鈹€鈹€鈹€鈹€鈹?          鈹?   鈹?鈹? 鈹斺攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹?   鈹?鈹斺攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹?```

## 馃搧 Project Structure

```
halo-blog/
鈹溾攢鈹€ src/
鈹?  鈹溾攢鈹€ main.py              # Application entry point
鈹?  鈹溾攢鈹€ config.py             # Configuration management
鈹?  鈹溾攢鈹€ domain/
鈹?  鈹?  鈹溾攢鈹€ models.py         # SQLAlchemy ORM models
鈹?  鈹?  鈹斺攢鈹€ schemas.py        # Pydantic schemas
鈹?  鈹溾攢鈹€ adapters/
鈹?  鈹?  鈹斺攢鈹€ database.py       # Database engine & session
鈹?  鈹溾攢鈹€ services/
鈹?  鈹?  鈹溾攢鈹€ post_service.py   # Post CRUD operations
鈹?  鈹?  鈹溾攢鈹€ comment_service.py# Comment management
鈹?  鈹?  鈹斺攢鈹€ auth.py           # JWT authentication
鈹?  鈹溾攢鈹€ api/
鈹?  鈹?  鈹溾攢鈹€ blog_routes.py    # Public API endpoints
鈹?  鈹?  鈹斺攢鈹€ admin_routes.py   # Admin API endpoints
鈹?  鈹溾攢鈹€ templates/            # Jinja2 templates
鈹?  鈹斺攢鈹€ static/               # CSS & JavaScript
鈹溾攢鈹€ Dockerfile
鈹溾攢鈹€ docker-compose.yml
鈹溾攢鈹€ pyproject.toml
鈹斺攢鈹€ README.md
```

## 鈿欙笍 Configuration

All configuration is done via environment variables with `HALO_` prefix:

| Variable | Default | Description |
|----------|---------|-------------|
| `HALO_SECRET_KEY` | `change-me` | JWT signing secret |
| `HALO_ADMIN_USERNAME` | `admin` | Admin username |
| `HALO_ADMIN_PASSWORD` | `change-me` | Admin password |
| `HALO_BLOG_TITLE` | `My Blog` | Blog title |
| `HALO_BLOG_SUBTITLE` | `A personal blog...` | Blog subtitle |
| `HALO_POSTS_PER_PAGE` | `10` | Posts per page |
| `HALO_DEBUG` | `false` | Debug mode |

See [`.env.example`](.env.example) for all available options.

## 馃摗 API Documentation

The API follows RESTful conventions. Access interactive docs at:

- **Swagger UI:** http://localhost:8000/docs
- **ReDoc:** http://localhost:8000/redoc

### Public Endpoints

```
GET    /api/posts              # List posts (paginated)
GET    /api/posts/{slug}       # Get post by slug
GET    /api/categories         # List categories
GET    /api/tags               # List tags
GET    /api/archives           # Archives by month
GET    /api/links              # Friendship links
POST   /api/comments           # Submit comment
```

### Admin Endpoints (JWT Required)

```
POST   /admin/api/login        # Login
GET    /admin/api/dashboard    # Dashboard stats
CRUD   /admin/api/posts        # Post management
CRUD   /admin/api/categories   # Category management
CRUD   /admin/api/tags         # Tag management
CRUD   /admin/api/comments     # Comment management
CRUD   /admin/api/links        # Link management
GET/PUT /admin/api/settings    # System settings
```

## 馃洜锔?Development

```bash
# Install dev dependencies
pip install -e ".[dev]"

# Lint
ruff check .

# Format
ruff format .

# Type check
mypy src/

# Run tests
pytest --cov=src
```

## 馃摝 Deployment

### Production Checklist

1. Change `HALO_SECRET_KEY` to a random string
2. Change `HALO_ADMIN_PASSWORD`
3. Set `HALO_DEBUG=false`
4. Configure reverse proxy (Nginx)
5. Enable HTTPS

### Docker Commands

```bash
docker compose up -d              # Start
docker compose restart            # Restart
docker compose up -d --build      # Rebuild
docker compose down               # Stop
docker logs halo-blog             # View logs
```

## 馃搫 Documentation

- [椤圭洰鎶€鏈枃妗(docs/PROJECT_DOCUMENTATION.md) 鈥?Architecture, API, Database
- [绠＄悊鍚庡彴鎿嶄綔鎵嬪唽](docs/OPERATIONS_MANUAL.md) 鈥?Admin guide, Configuration
- [閮ㄧ讲鏁欑▼](docs/DEPLOYMENT.md) 鈥?Step-by-step deployment

## 馃 Contributing

Contributions are welcome! Please read the [Contributing Guide](CONTRIBUTING.md) first.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'feat: add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 馃摑 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 馃檹 Acknowledgments

- [Halo CMS](https://halo.run/) 鈥?Inspiration
- [FastAPI](https://fastapi.tiangolo.com/) 鈥?Web framework
- [SQLAlchemy](https://www.sqlalchemy.org/) 鈥?ORM
- [Jinja2](https://jinja.palletsprojects.com/) 鈥?Template engine

---

<p align="center">
  <small>漏 2026 ArcaneCoreX-dev | <a href="https://github.com/ArcaneCoreX-dev/">GitHub</a></small>
</p>
